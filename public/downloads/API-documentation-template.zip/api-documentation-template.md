# [API Name] Documentation

> Template — replace all bracketed placeholders `[like this]` before publishing. Two example endpoints are fully worked out below the template pattern so you can see the format applied to something real.

**Base URL:** `https://api.example.com/v1`
**Version:** `1.0`
**Last Updated:** `[YYYY-MM-DD]`

---

## Table of Contents

- [Authentication](#authentication)
- [Endpoint Documentation Format](#endpoint-documentation-format)
- [Example: Get a User](#example-get-a-user)
- [Example: Create a User](#example-create-a-user)
- [Error Code Reference](#error-code-reference)
- [Usage Examples](#usage-examples)

---

## Authentication

This API uses **Bearer token authentication**. Include your API key in the `Authorization` header of every request.

```bash
curl https://api.example.com/v1/users/123 \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Obtaining a Key

`[Explain how a developer gets an API key — a dashboard link, a signup flow, or who to contact internally.]`

### Key Rotation

`[State how often keys should be rotated, and what happens to requests made with a revoked key — do they fail immediately, or is there a grace period?]`

---

## Endpoint Documentation Format

Use this exact structure for every endpoint, so documentation stays consistent and predictable across the whole API.

```
### [HTTP Method] [Path]

[One or two sentences: what this endpoint does and when to use it —
not just a restatement of the method and path.]

**Parameters**

| Name | Type | Required | Description |
|------|------|----------|-------------|
| ...  | ...  | ...      | ...         |

**Request Example**

[code block]

**Response Example**

[code block]

**Status Codes**

| Code | Meaning |
|------|---------|
| ...  | ...     |
```

The two worked examples below follow this exact pattern — copy one as a starting point for your own endpoints rather than starting from a blank page.

---

## Example: Get a User

### GET /users/{id}

Retrieves a single user by their unique ID. Use this when you already know the user's ID; use `GET /users` with a search filter if you only have partial information like an email address.

**Parameters**

| Name | Type   | Required | Description                        |
|------|--------|----------|-------------------------------------|
| id   | string | Yes      | The unique identifier of the user   |

**Request Example**

```bash
curl https://api.example.com/v1/users/usr_8f3a2b \
  -H "Authorization: Bearer YOUR_API_KEY"
```

**Response Example**

```json
{
  "id": "usr_8f3a2b",
  "email": "j.alvarez@example.com",
  "name": "J. Alvarez",
  "created_at": "2025-01-06T09:15:00Z",
  "status": "active"
}
```

**Status Codes**

| Code | Meaning                                      |
|------|-----------------------------------------------|
| 200  | User found and returned successfully          |
| 401  | Missing or invalid API key                    |
| 404  | No user exists with the given ID              |

---

## Example: Create a User

### POST /users

Creates a new user record. Returns the full created user object, including the server-generated `id`, so you don't need to make a follow-up `GET` request to retrieve it.

**Parameters**

| Name  | Type   | Required | Description                          |
|-------|--------|----------|----------------------------------------|
| email | string | Yes      | Must be a unique, valid email address  |
| name  | string | Yes      | Full display name                      |

**Request Example**

```bash
curl -X POST https://api.example.com/v1/users \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "j.alvarez@example.com",
    "name": "J. Alvarez"
  }'
```

**Response Example**

```json
{
  "id": "usr_8f3a2b",
  "email": "j.alvarez@example.com",
  "name": "J. Alvarez",
  "created_at": "2025-01-06T09:15:00Z",
  "status": "active"
}
```

**Status Codes**

| Code | Meaning                                              |
|------|--------------------------------------------------------|
| 201  | User created successfully                             |
| 400  | Request body missing a required field, or malformed    |
| 409  | A user with this email already exists                 |

---

## Error Code Reference

Every error response follows the same shape:

```json
{
  "error": {
    "code": "invalid_request",
    "message": "The 'email' field is required.",
    "request_id": "req_1a2b3c"
  }
}
```

Include the `request_id` when contacting support about a specific failed request — it lets us find the exact request in our logs without needing you to reproduce it.

| HTTP Status | Error Code             | Common Cause                                                |
|-------------|-------------------------|----------------------------------------------------------------|
| 400         | `invalid_request`       | A required field is missing, or a field has the wrong type    |
| 401         | `unauthorized`          | API key missing, expired, or revoked                          |
| 403         | `forbidden`             | Key is valid but lacks permission for this action              |
| 404         | `not_found`             | The requested resource doesn't exist                           |
| 409         | `conflict`              | The request conflicts with existing data (e.g. duplicate email)|
| 429         | `rate_limited`          | Too many requests in a short window — see rate limit headers  |
| 500         | `internal_error`        | Something failed on our end — safe to retry after a short wait |

---

## Usage Examples

### Basic Workflow: Create Then Fetch

A common pattern is creating a resource and then immediately fetching related data about it.

```bash
# 1. Create the user
curl -X POST https://api.example.com/v1/users \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email": "j.alvarez@example.com", "name": "J. Alvarez"}'

# Response includes the new user's id, e.g. "usr_8f3a2b"

# 2. Use that id in a follow-up request
curl https://api.example.com/v1/users/usr_8f3a2b/orders \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### Handling Rate Limits

Every response includes rate limit headers, whether or not you've hit the limit:

```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 998
X-RateLimit-Reset: 1704531600
```

If you receive a `429`, wait until the Unix timestamp in `X-RateLimit-Reset` before retrying, rather than retrying immediately.

### Pagination

Endpoints that return lists are paginated using a cursor, not page numbers:

```bash
curl "https://api.example.com/v1/users?limit=20&cursor=usr_8f3a2b" \
  -H "Authorization: Bearer YOUR_API_KEY"
```

The response includes a `next_cursor` field — pass it as the `cursor` parameter on your next request to get the following page. A `null` value for `next_cursor` means you've reached the end of the results.

---

*Rows, values, and examples shown are illustrative — replace with your actual API's real endpoints, fields, and error codes before publishing.*
